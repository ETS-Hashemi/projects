# swarmaze/__init__.py
"""
swarmaze: A pathfinding visualizer for 2D mazes using Pygame.
"""
